// Import spec files individually for Stackblitz
import './app/simple-test/welcome.component.spec.ts';
import './app/simple-test/CalculatorWithoutInput.component.spec.ts';

